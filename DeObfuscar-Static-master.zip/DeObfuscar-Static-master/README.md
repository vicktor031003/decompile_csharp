# Static Obfuscar Deobfuscator

## How to use
-Drag n Drop

## Notes:
-This is a very simple deobfuscator for Obfuscar

-Enjoy!
