Originally written by DerPopo ( http://7daystodie.com/forums/member.php?908-DerPopo ).

Modified by me to set class / field / method names to specific values.
